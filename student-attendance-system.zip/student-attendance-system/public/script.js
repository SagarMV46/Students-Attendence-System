const API = "http://localhost:5000/api";

async function login() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const message = document.getElementById("loginMessage");

  const res = await fetch(`${API}/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });

  const data = await res.json();

  if (res.ok) {
    localStorage.setItem("admin", username);
    window.location.href = "dashboard.html";
  } else {
    message.textContent = data.message;
  }
}

async function addStudent() {
  const student = {
    roll_no: document.getElementById("roll_no").value,
    name: document.getElementById("name").value,
    department: document.getElementById("department").value,
    semester: document.getElementById("semester").value,
    email: document.getElementById("email").value
  };

  const res = await fetch(`${API}/students`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(student)
  });

  const data = await res.json();
  alert(data.message);

  loadStudents();
  loadSummary();
}

async function loadStudents() {
  const res = await fetch(`${API}/students`);
  const students = await res.json();

  const table = document.getElementById("studentTable");
  const select = document.getElementById("studentSelect");

  if (!table || !select) return;

  table.innerHTML = "";
  select.innerHTML = "";

  students.forEach((student) => {
    table.innerHTML += `
      <tr>
        <td>${student.roll_no}</td>
        <td>${student.name}</td>
        <td>${student.department}</td>
        <td>${student.semester}</td>
        <td>${student.email || "-"}</td>
      </tr>
    `;

    select.innerHTML += `
      <option value="${student.id}">
        ${student.roll_no} - ${student.name}
      </option>
    `;
  });
}

async function markAttendance() {
  const attendance = {
    student_id: document.getElementById("studentSelect").value,
    status: document.getElementById("status").value,
    attendance_date: document.getElementById("attendanceDate").value
  };

  if (!attendance.attendance_date) {
    alert("Please select attendance date");
    return;
  }

  const res = await fetch(`${API}/attendance`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(attendance)
  });

  const data = await res.json();
  alert(data.message);

  loadAttendance();
  loadSummary();
  loadPerformance();
}

async function loadAttendance() {
  const res = await fetch(`${API}/attendance`);
  const records = await res.json();

  const table = document.getElementById("attendanceTable");
  if (!table) return;

  table.innerHTML = "";

  records.forEach((record) => {
    table.innerHTML += `
      <tr>
        <td>${record.roll_no}</td>
        <td>${record.name}</td>
        <td>${record.department}</td>
        <td>${record.semester}</td>
        <td>${record.status}</td>
        <td>${record.attendance_date.split("T")[0]}</td>
      </tr>
    `;
  });
}

async function loadSummary() {
  const res = await fetch(`${API}/summary`);
  const data = await res.json();

  if (!document.getElementById("totalStudents")) return;

  document.getElementById("totalStudents").textContent = data.totalStudents || 0;
  document.getElementById("totalRecords").textContent = data.totalRecords || 0;
  document.getElementById("presentCount").textContent = data.presentCount || 0;
  document.getElementById("absentCount").textContent = data.absentCount || 0;
}

async function loadPerformance() {
  const res = await fetch(`${API}/student-performance`);
  const students = await res.json();

  const list = document.getElementById("performanceList");
  if (!list) return;

  list.innerHTML = "";

  students.forEach((student) => {
    const percentage = student.percentage || 0;
    const warningClass = percentage < 75 ? "alert" : "alert good";

    list.innerHTML += `
      <div class="${warningClass}">
        ${student.name} (${student.roll_no}) - Attendance: ${percentage}% 
        ${percentage < 75 ? "Low attendance warning" : "Good standing"}
      </div>
    `;
  });
}

function filterTable() {
  const value = document.getElementById("searchInput").value.toLowerCase();
  const rows = document.querySelectorAll("#attendanceTable tr");

  rows.forEach((row) => {
    row.style.display = row.textContent.toLowerCase().includes(value) ? "" : "none";
  });
}

function exportCSV() {
  const rows = document.querySelectorAll("#attendanceTable tr");
  let csv = "Roll No,Name,Department,Semester,Status,Date\n";

  rows.forEach((row) => {
    const cols = row.querySelectorAll("td");
    const data = Array.from(cols).map((col) => col.textContent.trim());
    csv += data.join(",") + "\n";
  });

  const blob = new Blob([csv], { type: "text/csv" });
  const link = document.createElement("a");

  link.href = URL.createObjectURL(blob);
  link.download = "attendance_records.csv";
  link.click();
}

window.onload = () => {
  const today = new Date().toISOString().split("T")[0];
  const dateInput = document.getElementById("attendanceDate");

  if (dateInput) dateInput.value = today;

  loadStudents();
  loadAttendance();
  loadSummary();
  loadPerformance();
};