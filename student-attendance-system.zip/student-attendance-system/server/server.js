require("dotenv").config();

const express = require("express");
const cors = require("cors");
const db = require("./db");

const app = express();

app.use(cors());
app.use(express.json());

app.post("/api/login", (req, res) => {
  const { username, password } = req.body;

  db.query(
    "SELECT * FROM admins WHERE username = ? AND password = ?",
    [username, password],
    (err, result) => {
      if (err) return res.status(500).json({ message: "Server error" });

      if (result.length === 0) {
        return res.status(401).json({ message: "Invalid login details" });
      }

      res.json({ message: "Login successful", admin: result[0] });
    }
  );
});

app.post("/api/students", (req, res) => {
  const { roll_no, name, department, semester, email } = req.body;

  db.query(
    "INSERT INTO students (roll_no, name, department, semester, email) VALUES (?, ?, ?, ?, ?)",
    [roll_no, name, department, semester, email],
    (err) => {
      if (err) return res.status(500).json({ message: "Student already exists or server error" });

      res.json({ message: "Student added successfully" });
    }
  );
});

app.get("/api/students", (req, res) => {
  db.query("SELECT * FROM students ORDER BY id DESC", (err, result) => {
    if (err) return res.status(500).json({ message: "Server error" });

    res.json(result);
  });
});

app.post("/api/attendance", (req, res) => {
  const { student_id, status, attendance_date } = req.body;

  db.query(
    "INSERT INTO attendance (student_id, status, attendance_date) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE status = VALUES(status)",
    [student_id, status, attendance_date],
    (err) => {
      if (err) return res.status(500).json({ message: "Attendance error" });

      res.json({ message: "Attendance marked successfully" });
    }
  );
});

app.get("/api/attendance", (req, res) => {
  db.query(
    `SELECT 
      a.id,
      s.roll_no,
      s.name,
      s.department,
      s.semester,
      a.status,
      a.attendance_date,
      a.marked_at
    FROM attendance a
    JOIN students s ON a.student_id = s.id
    ORDER BY a.attendance_date DESC`,
    (err, result) => {
      if (err) return res.status(500).json({ message: "Server error" });

      res.json(result);
    }
  );
});

app.get("/api/summary", (req, res) => {
  db.query(
    `SELECT 
      COUNT(DISTINCT s.id) AS totalStudents,
      COUNT(a.id) AS totalRecords,
      SUM(a.status = 'Present') AS presentCount,
      SUM(a.status = 'Absent') AS absentCount,
      SUM(a.status = 'Late') AS lateCount
    FROM students s
    LEFT JOIN attendance a ON s.id = a.student_id`,
    (err, result) => {
      if (err) return res.status(500).json({ message: "Server error" });

      res.json(result[0]);
    }
  );
});

app.get("/api/student-performance", (req, res) => {
  db.query(
    `SELECT 
      s.id,
      s.roll_no,
      s.name,
      COUNT(a.id) AS totalClasses,
      SUM(a.status = 'Present') AS presents,
      ROUND((SUM(a.status = 'Present') / COUNT(a.id)) * 100, 2) AS percentage
    FROM students s
    LEFT JOIN attendance a ON s.id = a.student_id
    GROUP BY s.id
    ORDER BY percentage ASC`,
    (err, result) => {
      if (err) return res.status(500).json({ message: "Server error" });

      res.json(result);
    }
  );
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});